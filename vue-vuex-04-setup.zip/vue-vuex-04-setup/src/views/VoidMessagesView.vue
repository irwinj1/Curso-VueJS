<template>
  <div class="void-messages-view">
    <h4>Seleccione un canal</h4>
  </div>
</template>

<style lang="scss" scoped>
.void-messages-view {
  @apply flex w-full h-full justify-center items-center;
  h4 {
    @apply font-bold text-xl;
  }
}
</style>