import { createStore } from 'vuex'

const store = createStore({
  
})

export default store