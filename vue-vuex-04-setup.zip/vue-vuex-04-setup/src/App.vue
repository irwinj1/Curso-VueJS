<script setup>
import { RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

<style lang="scss">
body {
  @apply bg-neutral-900 text-gray-200;
}
</style>
